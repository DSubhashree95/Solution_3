// getting all required elements
const searchWrapper = document.querySelector(".search-input");
const inputBox = searchWrapper.querySelector("input");
const suggBox = searchWrapper.querySelector(".autocom-result");
const searchResultsDiv = document.querySelector(".search-results");
const searchHistoryDiv = document.querySelector(".history-results");
const icon = searchWrapper.querySelector(".icon");

// Container to hold the history
var historyData = {data: []};

// if user press any key and release
inputBox.onkeyup = (e)=>{
	 let searchValue = e.target.value; 
	 // Checking for Key Enter(13)
	 if(event.keyCode == 13)
	 {
		 // Checking for Input
		if(searchValue == "")
		{
			searchResultsDiv.innerHTML='Invalid search input';
			return 0;
		}
		// Search for Input Keyword
		search(searchValue);
		return 0;
	 }
	 let emptyArray = [];
	suggBox.style.display = "block";

	// Rest API Initialization and Call
	const xhttp = new XMLHttpRequest();
	let suggestions=[];
	xhttp.onload = function() {
		
		// Filtering Results
		 var responseData = JSON.parse(this.responseText);
			var data= responseData.data;
			for (let i = 0; i < data.length; i++) {
				suggestions[i]=data[i].name;
			}
			emptyArray = [...new Set(suggestions)];
			
			// Highlighting search keyword on the Suggestions list
			emptyArray = emptyArray.map((data)=>{
				if(data.startsWith(searchValue)){
					data = data.replace(searchValue,"");
					data = `<li><b>${searchValue}</b>${data}</li>`;
					 return data;
				}
			});
			showSuggestions(emptyArray);
			
            // Setting Click Event on Suggestions
			searchWrapper.classList.add("active");
			let allList = suggBox.querySelectorAll("li");
			for (let i = 0; i < allList.length; i++) {
				allList[i].setAttribute("onclick", "select(this)");
			}
	}
	
	xhttp.open(searchAPI.type, Host.URL+searchAPI.resource+searchAPI.queryParam+searchValue);
	xhttp.send();
}

// Search for Selected Result from Suggestions
function select(element){
    let selectData = element.textContent;
	search(selectData);
}
// Search for Selected Result from Suggestions
function search(selectData){
    inputBox.value = selectData;
	addToHistoryData(selectData);
	callSearchAPI(selectData); 
    searchWrapper.classList.remove("active");
}
// Add Search Keyword to Search History
function addToHistoryData(selectData){
	var today = new Date();
	var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate() +", " + formatAMPM(today);
	historyData.data.push({"selectData": selectData, "timestamp" : date});
}

// Clear All History 
function clearAllHistory(){
	historyData = {data: []};
	createHistoryTable();
}

// Deleting Selected History 
function clearHistory(selectData, timestamp){
	var data= historyData.data;
	var historyDataTemp = {data: []};
	if(data.length != 0)
	{
		for (let i = 0; i < data.length; i++) {
			if(!(data[i].selectData == selectData && data[i].timestamp == timestamp))
			{
				historyDataTemp.data.push(data[i]);
			}
		}
	}
	
	historyData = historyDataTemp;
	// Rebuilding table after detele history
	createHistoryTable();
}

// Creating History Table based on Preserved History
function createHistoryTable(){
	var data= historyData.data;
	if(data.length != 0)
	{
		var divTable = document.createElement("TABLE");
		divTable.setAttribute("id", "searchHistoryTable");
		 var row = document.createElement("TR");
		  row.setAttribute("id", "row");
		  divTable.appendChild(row);
		  var col= document.createElement("TH");
		  var cell = document.createTextNode("Search History");
		  col.appendChild(cell);
		  row.appendChild(col);
		  
		  var colLink= document.createElement("TH");
		  colLink.colSpan=2;
		  
		  var divHist = document.createElement('div');
		  divHist.setAttribute("id", "clearAllHistory");
		  divHist.innerHTML = "<u> Clear Search History </u>";
		  colLink.setAttribute("onclick", "clearAllHistory()");
		  colLink.appendChild(divHist);
		  row.appendChild(colLink);
		  
		  
		for (let i = 0; i < data.length; i++) {
		  var row = document.createElement("TR");
		  row.setAttribute("id", "row");
		  divTable.appendChild(row);
		  var dataJson = data[i];
		
		  for (var key in dataJson) {
			var col = document.createElement("TD");
			var cell = document.createTextNode(dataJson[key]);
			col.appendChild(cell);
			row.appendChild(col);
		  }	  
		  var colLink = document.createElement("TD");
		  var divLink = document.createElement('div');
		  divLink.className +="fa fa-close fa-pull-center fa-2x ";
		  divLink.setAttribute("onclick", "clearHistory('"+dataJson.selectData+"','"+dataJson.timestamp+"')");
		  colLink.appendChild(divLink);
		  row.appendChild(colLink);
		
		}
		searchHistoryDiv.innerHTML='';
		searchHistoryDiv.append(divTable);
	}else{
		searchHistoryDiv.innerHTML='';
	}

}

// API call
function callSearchAPI(selectData){
   const xhttp = new XMLHttpRequest();
	xhttp.onload = function() {
		 createResultTable(this.responseText,selectData);
		 createHistoryTable();
	}

	xhttp.open(searchAPI.type, Host.URL+searchAPI.resource+searchAPI.queryParam+selectData);
	xhttp.send();
}

// Creating Result Table to show search result
function createResultTable(responseText,selectData){
	let headers =["Id","Name","Email","Gender","Status"];
    var responseData = JSON.parse(responseText);
	var data= responseData.data;
	if(data.length!=0)
	{
		var divTable = document.createElement("TABLE");
		divTable.setAttribute("id", "searchResultsTable");
		 var row = document.createElement("TR");
		  row.setAttribute("id", "row");
		  divTable.appendChild(row);
		  for (var key in headers) {
			var col = document.createElement("TH");
			var cell = document.createTextNode(headers[key]);
			col.appendChild(cell);
			row.appendChild(col);
		  }
		  
		for (let i = 0; i < data.length; i++) {
		  var row = document.createElement("TR");
		  row.setAttribute("id", "row");
		  divTable.appendChild(row);
		  var dataJson = data[i];
		  for (var key in dataJson) {
			var col = document.createElement("TD");
			var cell = document.createTextNode(dataJson[key]);
			col.appendChild(cell);
			row.appendChild(col);
		  }
		  
		  
		}
		searchResultsDiv.innerHTML='';
		searchResultsDiv.append(divTable);
	}
	else{
		searchResultsDiv.innerHTML='No Result found for "<b>' +selectData +'</b>"';
	}
}
	
// Show Suggestions
function showSuggestions(list){
    let listData;
    if(!list.length){
        userValue = inputBox.value;
        listData = `<li>${userValue}</li>`;
    }else{
      listData = list.join('');
    }
    suggBox.innerHTML = listData;
}

// Clear Input Text Box
function clearText(){
    inputBox.value = '';
	suggBox.innerHTML ='';
	suggBox.style.display = "none";
}

// Formatting date for History
function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}