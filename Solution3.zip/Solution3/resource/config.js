
Host = {
 URL: 'https://gorest.co.in',
};

searchAPI = {
 resource: '/public/v1/users',
 queryParam: '?name=',
 type: 'GET'
}